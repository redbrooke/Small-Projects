/*
Version normalizer and comparison library for go, heavy based on PHP 
version_compare function and Version comparsion libs from Composer 
(https://github.com/composer/composer) PHP project
*/
package version