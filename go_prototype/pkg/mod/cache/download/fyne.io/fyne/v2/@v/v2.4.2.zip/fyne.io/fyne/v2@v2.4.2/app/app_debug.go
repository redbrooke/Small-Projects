//go:build debug
// +build debug

package app

import "fyne.io/fyne/v2"

const buildMode = fyne.BuildDebug
